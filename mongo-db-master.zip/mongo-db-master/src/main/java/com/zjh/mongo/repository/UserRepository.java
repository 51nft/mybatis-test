package com.zjh.mongo.repository;


import com.zjh.mongo.pojo.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends MongoRepository<User,String> {

    User findByNameAndAge(String name, Integer age);

    List<User> findByAgeBetween(Integer age, Integer age1);

    List<User> findByNameLike(String name);

}
