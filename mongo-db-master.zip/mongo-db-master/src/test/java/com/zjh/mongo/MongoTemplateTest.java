package com.zjh.mongo;


import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import com.zjh.mongo.pojo.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import java.util.List;
import java.util.regex.Pattern;

@SpringBootTest
public class MongoTemplateTest {

    @Autowired
    MongoTemplate mongoTemplate;

    //添加
    @Test
    public void testInsert(){
        User user = new User();
        user.setName("zzz");
        user.setAge(22);
        user.setEmail("zjh@qq.com");
        User u = mongoTemplate.insert(user);
        System.out.println(u);
    }

    // 查询所有
    @Test
    public void testFindAll(){
        List<User> userList = mongoTemplate.findAll(User.class);
        userList.forEach(System.out::println);
    }

    // 根据id查询
    @Test
    public void testFindById(){
        User user = mongoTemplate.findById("64a223f74a26432bd36f037c", User.class);
        System.out.println(user);
    }

    // 条件查询
    @Test
    public void testFindQuery(){
        // 设置查询条件
        Query query = new Query(Criteria
                .where("name").is("zjh")
                .and("age").gt(20));
        List<User> userList = mongoTemplate.find(query, User.class);
        userList.forEach(System.out::println);
    }

    // 模糊查询
    @Test
    public void testFindLike(){
        String name = "j";
        // 设置查询条件   %s%s%s相当于要传三个数据
        String regex = String.format("%s%s%s", "^.*", name, ".*$");
        Pattern pattern = Pattern.compile(regex,Pattern.CASE_INSENSITIVE); // 忽略大小写
        Query query = new Query(Criteria.where("name").regex(pattern));
        List<User> userList = mongoTemplate.find(query, User.class);
        userList.forEach(System.out::println);
    }

    // 分页查询
    @Test
    public void testFindByPage(){
        String name = "z";
        // 设置查询条件
        String regex = String.format("%s%s%s", "^.*", name, ".*$");
        Pattern pattern = Pattern.compile(regex,Pattern.CASE_INSENSITIVE); // 忽略大小写
        Query query = new Query(Criteria.where("name").regex(pattern));
        // 分页查询
        int page = 1;
        int size = 2;
        List<User> userList = mongoTemplate.find(query.skip((page-1)*size).limit(size), User.class);
        userList.forEach(System.out::println);
    }


    // 修改
    @Test
    public void testUpdate(){
        // 查询条件
        Query query = new Query(Criteria.where("name").is("sss"));
        // 修改后的数据
        Update update = new Update();
        update.set("name", "sss修改后");
        update.set("age", 100);
        UpdateResult result = mongoTemplate.upsert(query, update, User.class);
        System.out.println(result.getModifiedCount());
    }

    // 测试删除
    @Test
    public void testDelete(){
        Query query = new Query(Criteria.where("_id").is("64a17765100dc24ae8da733f"));
        DeleteResult result = mongoTemplate.remove(query, User.class);
        System.out.println(result.getDeletedCount());
    }

}
