package com.zjh.mongo;
import com.zjh.mongo.pojo.User;
import com.zjh.mongo.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@SpringBootTest
public class MongoRepositoryTest {

    @Autowired
    UserRepository userRepository;

    // 添加
    @Test
    public void testInsert(){
        User user = new User();
        user.setName("wxe");
        user.setAge(22);
        user.setEmail("wmm@qq.com");
        User u = userRepository.save(user);
        System.out.println(u);
    }

    // 查询所有
    @Test
    public void testFindAll(){
        List<User> userList = userRepository.findAll();
        userList.forEach(System.out::println);
    }

    // 根据id查询
    @Test
    public void testFindById(){
        Optional<User> optional = userRepository.findById("64a177c58e767e6095b04c82");
        if (optional.isPresent()) {
            User user = optional.get();
            System.out.println(user);
        }
    }

    // 测试条件查询
    @Test
    public void testFindQuery(){
        // 构造条件
        User user = new User();
        user.setName("wmm");
        Example<User> example = Example.of(user);
        List<User> userList = userRepository.findAll(example);
        userList.forEach(System.out::println);
    }

    // 测试模糊查询
    @Test
    public void testFindLike(){
        // 构造条件
        User user = new User();
        user.setName("m");
        Example<User> example = Example.of(user, ExampleMatcher.matching()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING) // 包含 模糊查询
                .withIgnoreCase(true)); // 忽略大小写
        List<User> userList = userRepository.findAll(example);
        userList.forEach(System.out::println);
    }

    // 测试分页查询
    @Test
    public void testFindByPage(){
        // 构造条件
        User user = new User();
        user.setName("w");
        Example<User> example = Example.of(user, ExampleMatcher.matching()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING) // 包含 模糊查询
                .withIgnoreCase(true)); // 忽略大小写
        // 构造PageRequest对象
        int page = 1;
        int size = 2;
        // page从0开始
        PageRequest pageRequest = PageRequest.of(page-1, size);
        Page<User> userPage = userRepository.findAll(example, pageRequest);
        // 总记录数据
        System.out.println("总记录数：" + userPage.getTotalElements());
        // 总页数
        System.out.println("总页数：" + userPage.getTotalPages());
        // 列表数据
        List<User> userList = userPage.getContent();
        userList.forEach(System.out::println);
    }


    // 测试修改
    @Test
    public void testUpdate(){
        Optional<User> optional = userRepository.findById("643660a72a386e7a05f68580");
        if (optional.isPresent()) {
            User user = optional.get();
            user.setName("鸡你太美");
            user.setAge(18);
            userRepository.save(user);
        }
    }

    // 测试删除
    @Test
    public void testDelete(){
        userRepository.deleteById("64a1785da4ac95399d2dd763");
    }

    // 测试自定义方法
    @Test
    public void testFindByNameAndAge(){
        // User user = userRepository.findByNameAndAge("wmm", 22);
        // System.out.println(user);

        // List<User> userList = userRepository.findByAgeBetween(18, 28);
        // userList.forEach(System.out::println);

        List<User> userList = userRepository.findByNameLike("wmm");
        userList.forEach(System.out::println);

    }

}
